<%
response.sendRedirect("home.jsp");
%>
